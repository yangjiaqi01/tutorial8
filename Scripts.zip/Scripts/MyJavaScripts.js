function msg() {
    alert("Hello World!");
}   